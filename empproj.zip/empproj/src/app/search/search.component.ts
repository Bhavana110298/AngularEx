import { Component, OnInit } from '@angular/core';
import { EmpserviceService, Employee } from '../empservice.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  service: EmpserviceService;
  emp: Employee[] = [];
  constructor(service: EmpserviceService) {
    this.service = service;
  }
  search(data) {
    this.emp = this.service.search(data);
  }

  ngOnInit() {
  }

}


