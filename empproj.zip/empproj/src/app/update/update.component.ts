import { Component, OnInit } from '@angular/core';
import { Employee, EmpserviceService } from '../empservice.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  createdEmployee:Employee;

  createdFlag:boolean=false;
  service:EmpserviceService;
  constructor(service:EmpserviceService) {
    this.service=service;
   }

  ngOnInit() {
  }

  update(data:any) {
    this.createdEmployee=new Employee(data.dptId,data.dptName);
    this.service.update(this.createdEmployee);
    this.createdFlag=true;
  }

}
