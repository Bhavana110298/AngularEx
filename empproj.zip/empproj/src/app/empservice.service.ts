import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmpserviceService {
  http: HttpClient;
  department: Employee[] = [];
  constructor(http: HttpClient) {
    this.http = http;
  }
  fetched: boolean = false;
  fetchdepartment() {
    this.http.get('./assets/department.json')
      .subscribe(
        data => {
          if (!this.fetched) {
            this.convert(data);
            this.fetched = true;
          }
        }
      );
  }
  getdepartment(): Employee[] {
    return this.department;
  }
  convert(data: any) {
    for (let o of data) {
      let d = new Employee(o.dptId, o.dptName);
      this.department.push(d)
    }
  }
  delete(dptId: number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.department.length;i++) {
      let e=this.department[i];
      if(dptId==e.dptId) {
        foundIndex=i;
        break;
      }
    }
    this.department.splice(foundIndex,1);
  }
  add(newEmployee:Employee){
    this.department.push(newEmployee);
  }
  
  searchEmpArr: Employee[];
  search(data): Employee[] {
  this.searchEmpArr = [];
  for (let e of this.department) {
  if (e.dptId == data.dptId) {
  this.searchEmpArr.push(e);
  }
  }
  return this.searchEmpArr;
  }
  update(d:Employee) {
    for(let i=0;i<this.department.length;i++) {
      if(d.dptId==this.department[i].dptId) {
        this.department[i].dptName=d.dptName;
        break;
      }
    }
  }
}
export class Employee {
  dptId: number;
  dptName: string;
  constructor(dptId: number,
    dptName: string) {
    this.dptId = dptId;
    this.dptName = dptName;
  }
}

