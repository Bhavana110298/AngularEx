import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';

import { EmpserviceService} from './empservice.service';
import {HttpClient,HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import {OrderbyPipe} from './orderby.pipe';
import { UpdateComponent } from './update/update.component';
import { AddComponent } from './add/add.component';
import { SearchComponent } from './search/search.component';
@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    OrderbyPipe,
    UpdateComponent,
    AddComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient,EmpserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
