import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { UpdateComponent } from './update/update.component';
import { AddComponent } from './add/add.component';
import { SearchComponent } from './search/search.component';


const routes: Routes = [
  {
    path: 'app-employee',
    component: EmployeeComponent
  },
  {
    path: 'app-update',
    component: UpdateComponent
  },
  {
    path:'app-add',
    component:AddComponent
  },
  {
    path:'app-search',
    component:SearchComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
