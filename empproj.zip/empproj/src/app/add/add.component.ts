import { Component, OnInit } from '@angular/core';
import { EmpserviceService, Employee } from '../empservice.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
service:EmpserviceService;
createdEmployee:Employee;
createdFlag:boolean=false;
  constructor(service:EmpserviceService) { 
  this.service=service;
}
  ngOnInit() {
  }
add(data:any) {
  this.createdEmployee=new Employee(data.dptId,data.dptName);
  this.service.add(this.createdEmployee);
  this.createdFlag=true;
}
}
