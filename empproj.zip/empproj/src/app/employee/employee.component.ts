import { Component, OnInit } from '@angular/core';
import { EmpserviceService, Employee } from '../empservice.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  service: EmpserviceService;

  constructor(service: EmpserviceService) {
    this.service = service;
  }
  department: Employee[] = []
  delete(dptId: number) {
    this.service.delete(dptId);
    this.department = this.service.getdepartment();
  }
  column: string = "dptId";
  order: boolean = true;
  sort(column: string) {
    if (this.column = column) {
      this.order = !this.order;
    }
    else {
      this.order = true;
      this.column = column;
    }
  }
  ngOnInit() {
    this.service.fetchdepartment();
    this.department = this.service.getdepartment();
  }

}
