import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { EmployeeServiceService } from './employee-service.service';
import { ListAllEmployeesComponent } from './list-all-employees/list-all-employees.component';


@NgModule({
  declarations: [
    AppComponent,
    AddEmployeeComponent,
    ListAllEmployeesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
    
  ],
  providers: [HttpClient,EmployeeServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
