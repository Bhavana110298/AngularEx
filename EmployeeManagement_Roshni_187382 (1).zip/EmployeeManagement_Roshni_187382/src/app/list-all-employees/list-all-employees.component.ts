import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';
import { EmployeeServiceService } from '../employee-service.service';

@Component({
  selector: 'app-list-all-employees',
  templateUrl: './list-all-employees.component.html',
  styleUrls: ['./list-all-employees.component.css']
})
export class ListAllEmployeesComponent implements OnInit {
Emp:Employee[]=[];
EmployeeService:EmployeeServiceService;
  constructor(EmployeeService:EmployeeServiceService)
   { 
     this.EmployeeService=EmployeeService;
   }

  ngOnInit() {
    this.Emp=this.EmployeeService.GetEmployee();
  }
delete(e:Employee){
  this.EmployeeService.DeleteEmployee(e);
}
}
