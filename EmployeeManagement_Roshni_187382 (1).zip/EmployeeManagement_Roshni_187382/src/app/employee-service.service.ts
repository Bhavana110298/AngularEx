import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee} from './Employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {
http:HttpClient;
EmployeeArray:Employee[]=[];


  constructor(http:HttpClient) {
    this.http=http;
  }
  StoreEmployee(empobj:Employee){
    JSON.stringify(empobj);
    //his.http.post('./assest/Employee.json',myJSON);
    console.log("Added To Json");
   
  }
   AddEmployee(em:Employee){
     this.EmployeeArray.push(em);
    // let myJSON = JSON.stringify(this.EmployeeArray);

    }
    GetEmployee():Employee[]{
      return this.EmployeeArray;

    }
    DeleteEmployee(e:Employee){
      let index=this.EmployeeArray.indexOf(e);
      this.EmployeeArray.splice(index,1);
    }
}
