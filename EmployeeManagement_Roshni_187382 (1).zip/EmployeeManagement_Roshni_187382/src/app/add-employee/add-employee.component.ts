import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService } from '../employee-service.service';
import { Employee } from '../Employee';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
EmployeeService:EmployeeServiceService;
  constructor(EmployeeService:EmployeeServiceService) 
  {
    this.EmployeeService=EmployeeService;
   }

  ngOnInit() {
    
  }
  add(emp:any){
    if (emp.id!="" && emp.name != "" && emp.email!= "" && emp.phone != "") {
      let empobj=new Employee(emp.id,emp.name,emp.email,emp.phone);
      this.EmployeeService.AddEmployee(empobj);
      this.EmployeeService.StoreEmployee(empobj);
     
    }
    else{
      window.alert("please enter the required details");
    }
    
    
    
  }
  }


