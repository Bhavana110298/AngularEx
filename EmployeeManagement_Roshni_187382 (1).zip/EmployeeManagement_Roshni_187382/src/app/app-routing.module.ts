import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { ListAllEmployeesComponent } from './list-all-employees/list-all-employees.component';
const routes:Routes=[
  {
path:'app-add-employee',
component:AddEmployeeComponent
  },
  {
    path:'app-list-all-employees',
    component:ListAllEmployeesComponent
  }
 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
