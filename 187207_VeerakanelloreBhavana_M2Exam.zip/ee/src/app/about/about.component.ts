import { Component, OnInit } from '@angular/core';
import { ServeService } from '../serve.service';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  service: ServeService;

  constructor(service: ServeService) {
    this.service = service;
  }

  ngOnInit() {
  }

}
