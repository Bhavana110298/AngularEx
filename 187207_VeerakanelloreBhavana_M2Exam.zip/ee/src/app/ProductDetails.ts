export class ProductDetails {
    ProductId: string;
    Category: string;
    MainCategory: string;
    TaxTarifCode: number;
    SupplierName: string;
    constructor(ProductId: string, Category: string, MainCategory: string, TaxTarifCode: number, SupplierName: string) {
        this.ProductId = ProductId;
        this.Category = Category;
        this.MainCategory = MainCategory;
        this.TaxTarifCode = TaxTarifCode;
        this.SupplierName = SupplierName;
    }
}