import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProductDetails } from './ProductDetails';

@Injectable({
  providedIn: 'root'
})
export class ServeService {

  http: HttpClient;
  list: ProductDetails[] = [];
  fetch: boolean = false;

  constructor(http: HttpClient) {
    this.http = http;
  }
  fetchdata() {
    this.http.get('../assets/productBrands.json').subscribe(
      data => {
        if (!this.fetch) {
          this.convert(data);
          this.fetch = true;
        }
      }
    )
  }

  convert(data: any) {
    for (let p of data) {
      let pObj = new ProductDetails(p.ProductId, p.Category, p.MainCategory, p.TaxTarifCode, p.SupplierName);
      this.list.push(pObj);
    }
  }

  add(list: ProductDetails) {
    this.list.push(list);
  }

  getProduct(): ProductDetails[] {
    return this.list;
  }
}



