import { Component, OnInit } from '@angular/core';
import { ServeService} from '../serve.service';
import { ProductDetails } from '../ProductDetails';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  service : ServeService;
  list : ProductDetails[] = [];
  
  constructor(service : ServeService) {
    this.service = service;
   }

  ngOnInit() {
    this.service.fetchdata();
    this.list = this.service.getProduct();
  }

}
